package com.example.adminopp_mgmt

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
