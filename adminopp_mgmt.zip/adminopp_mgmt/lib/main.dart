import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:openid_client/openid_client.dart';
import 'package:url_launcher/url_launcher.dart';
import 'KeyCloak/oidc_client_singleton.dart';
import 'WebViewExample.dart';
import 'styling.dart';

Future<void> main() async {
  print("Inside main");
  var oidcClient = OIDCClient.getInstance(
      "enow-om-portal", "tJsVDsEmEbxyFN60tcHtq09z0QhXIQOm");
  UserInfo? userInfo = await oidcClient.getUserInfo();

  if (userInfo == null) {
    oidcClient.authenticate();
  } else {
    runApp(MyApp(userInfo: userInfo, oidcClient: oidcClient));
  }
}

class MyApp extends StatelessWidget {
  UserInfo userInfo;
  OIDCClient oidcClient;

  MyApp({super.key, required this.userInfo, required this.oidcClient});
  @override
  Widget build(BuildContext context) {
    print('Print Inside Myapp');
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.blue),
      home: Admin(userInfo: userInfo, oidcClient: oidcClient),
    );
  }
}

class Admin extends StatefulWidget {
  Admin({super.key, required this.userInfo, required this.oidcClient});

  UserInfo? userInfo;
  OIDCClient? oidcClient;
  @override
  _AdminState createState() => _AdminState();
}

class _AdminState extends State<Admin> {
  @override
  void initState() {
    print("Inside initState()");
    //oidcClient.getUserInfo().then((value) => userInfo = value);

    super.initState();
  }

  Widget build(BuildContext context) {
    print('Print Inside AdminApp');
    return Scaffold(
      backgroundColor: bgColor,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(90.0),
        child: AppBar(
          backgroundColor: primaryColor,
          title: h3Text(text: 'MANAGEMENT', weight: 2, color: 1),
          actions: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  h4Text(text: 'Hello User! Good Day', weight: 2, color: 1),
                ],
              ),
            ),
            const Padding(
              padding: EdgeInsets.all(8.0),
              child: Icon(
                Icons.account_circle,
                size: 40,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
      body: Row(
        children: [
          Container(
            width: 300,
            color: Colors.white,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: ListTile(
                    leading: SvgPicture.asset(
                      'assets/home.svg',
                      width: 24,
                      height: 24,
                    ),
                    title: const Text(
                      'Home',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                    onTap: () {},
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: ListTile(
                    leading: const Icon(
                      Icons.exit_to_app,
                      size: 24,
                      color: Colors.black,
                    ),
                    title: const Text(
                      'Logout',
                      style: TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                    onTap: () async {
                      setState(() {
                        widget.userInfo = null;
                      });
                      var oidcClient = OIDCClient.getInstance(
                          "enow-om-portal", "tJsVDsEmEbxyFN60tcHtq09z0QhXIQOm");
                      widget.oidcClient!.logOut();
                    },
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                h3Text(text: 'Home', weight: 2, color: 4),
                h4Text(
                    text:
                        'Please choose the type of service that you want to use',
                    weight: 2,
                    color: 3),
                const SizedBox(height: 16),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: <Widget>[
                      if (widget.userInfo != null) ...[
                        SizedBox(
                          width: 400,
                          child: Stack(
                            children: [
                              Card(
                                elevation: 4,
                                child: Container(
                                  width: double.infinity,
                                  height: 200,
                                  decoration: const BoxDecoration(
                                    gradient: LinearGradient(
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                      colors: [
                                        Colors.greenAccent,
                                        Colors.orangeAccent,
                                      ],
                                    ),
                                  ),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      SvgPicture.asset(
                                        'assets/contact.svg',
                                        width: 80,
                                        height: 80,
                                      ),
                                      const SizedBox(height: 8),
                                      Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: h4Text(
                                            text: 'LEAD MANAGEMENT',
                                            weight: 2,
                                            color: 4),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Positioned(
                                bottom: 8,
                                right: 8,
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: ElevatedButton(
                                    onPressed: () {
                                      /*launchUrl(
                                        Uri.parse('http://localhost:8012/'),
                                        mode: LaunchMode.externalApplication,
                                      );*/
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) => WebViewExample(
                                            url: 'http://localhost:8012/',
                                          ),
                                        ),
                                      );
                                    },
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.blue,
                                      shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(5.0),
                                      ),
                                    ),
                                    child: const Text(
                                      'GO',
                                      style: TextStyle(
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(width: 20),
                        SizedBox(
                          width: 400,
                          child: Stack(
                            children: [
                              Card(
                                elevation: 4,
                                child: Container(
                                  width: double.infinity,
                                  height: 200,
                                  decoration: const BoxDecoration(
                                    gradient: LinearGradient(
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                      colors: [
                                        Colors.greenAccent,
                                        Colors.orangeAccent,
                                      ],
                                    ),
                                  ),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      SvgPicture.asset(
                                        'assets/opp.svg',
                                        width: 80,
                                        height: 80,
                                      ),
                                      const SizedBox(height: 8),
                                      Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: h4Text(
                                            text: 'OPPORTUNITY MANAGEMENT',
                                            weight: 2,
                                            color: 4),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Positioned(
                                bottom: 8,
                                right: 8,
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: ElevatedButton(
                                    onPressed: () {
                                      /*launchUrl(
                                        Uri.parse('http://localhost:8013/'),
                                        mode: LaunchMode.externalApplication,
                                      );*/
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) => WebViewExample(
                                            url: 'http://localhost:8013/',
                                          ),
                                        ),
                                      );
                                    },
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.blue,
                                      shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(5.0),
                                      ),
                                    ),
                                    child: const Text(
                                      'GO',
                                      style: TextStyle(
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                      if (widget.userInfo == null)
                        Text('You are logged out from the application')
                      /*OutlinedButton(
                            child: const Text('Login'),
                            onPressed: () async {
                              //oidcClient.authenticate();

                              /* setState(() {
                      oidcClient.getUserInfo().then((value) => userInfo = value);
                    }); */
                            }),*/
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
