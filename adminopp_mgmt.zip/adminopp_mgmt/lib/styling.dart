import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'responsive.dart';

// Colors
const Color bgColor = Color(0xFFEEEFF1);
const Color primaryColor = Color(0xFF6784ED);

const Color loginGrad1 = Color(0xFF85A0FF);
const Color loginGrad2 = Color(0xFF9166D6);

// Button gradient color
const Color buttonGrad1 = Color(0xFFFFD27B);
const Color buttonGrad2 = Color(0xFFFFAF52);

// Button Colors
const Color saveButtonColor = Color(0xFF00E51E);
const Color cancelButtonColor = Color(0xFFD2D1D1);
const Color normalButtonColor = Color(0xFFFF856A);
const Color disabledDeleteIconColor = Color(0x33FF2525);
const Color disabledEditIconColor = Color(0x440000FF);
const Color floatingButtonColor = Color(0xFFFF856A);
const Color disabledNormalButtonColor = Color(0x33FF856A);
const Color disabledSaveButtonColor = Color(0x3300E51E);
const Color disabledCancelButtonColor = Color(0x33D2D1D1);

// Icon Colors
const Color reportIconColor = Color(0xFF9100E5);
const Color disabledReportIconColor = Color(0x339100E5);
const Color viewIconColor = Color(0xFF002655);
const Color acceptIconColor = Color(0xFF00E51E);

const Color highlightColor = Color(0xFFFF856A);
const Color alertColor = Color(0xFFFF2525);

// Other Colors
const Color dashboardCardColor = Color(0xCCFFFFFF);
const Color tableTagColor = Color(0xFF43495F);
const Color disabledColor = Color(0xFFAFAFAF);
const Color shadowColor = Color(0x28000000);
const Color menuPrimaryColor = Color(0xFF7581E0);
const Color menuSecondaryColor = Color(0xFF4C57B0);
const Color menuTertiaryColor = Color(0xFFF1F3FD);
const Color subMenuPrimaryColor = Color(0x1ABCC3DE);
const Color subMenuSecondaryColor = Color(0x33BCC3DE);
const Color popUpHeaderColor = Color(0xFFE3E3EE);
const Color transparentColor = Color(0x00FFFFFF);
const Color menuCanvasColor = Color(0xFFFFFFFF);
const Color linkColor = Color(0xFFB4D8FC);
const Color fullDayColor = Color(0xFF21D929);
const Color halfDayColor = Color(0xFFFF9A62);
const Color weekendColor = Color(0xFFD2D1D1);
const Color outsideWeekendColor = Color(0x77D2D1D1);
const Color outsideDayColor = Color(0xFF5A6276);
const Color holidayColor = Color(0xFFA106FF);
const Color outsideHolidayColor = Color(0x77A106FF);
const Color dashboardIconBorderColor = Color(0xFFDDE4FC);
const Color calendarDayStatusTagColor = Color(0xFFF9F9F9);

const Color activeUserColor = Color(0xFF32DC23);
const Color inactiveUserColor = Color(0xFFFF5B5B);
const Color subAlertDialogColor = Color(0x33D5DEFF);

const Color highPriorityColor = Color(0xFFFF5B5B);
const Color mediumPriorityColor = Color(0xFFFF9A62);
const Color lowPriorityColor = Color(0xFF21D929);

const Color activeSwitchColor = Color(0xFF6200EE);
const Color activeSwitchTrackColor = Color(0x616200EE);

// Spacing
double tinySpace = 5.0;
double smallSpace = 10.0;
double mediumSpace = 15.0;
double largeSpace = 20.0;
double hugeSpace = 30.0;

// Date Time Formatters
DateFormat dateTimeFormatter = DateFormat('dd MMM, yyyy HH:mm');
DateFormat dateFormatter = DateFormat('dd MMM, yyyy');
DateFormat timeFormatter = DateFormat('HH:mm');

// Font Colors
List<Color> borderColors = [
  const Color(0xFFE81123),
  const Color(0xFFD4D6DE),
  const Color(0xFFAFAFAF),
  const Color(0xFF9A9A9A),
  const Color(0xFF0054E5),
  const Color(0xFF00E51E)
];

// Font Colors
List<Color> fontColors = [
  const Color(0xFFE81123), //0
  const Color(0xFFFFFFFF), //1
  const Color(0xFFAFAFAF), //2
  const Color(0xFF5A6276), //3
  const Color(0xFF000000), //4
  const Color(0xFF0054E5), //5
  const Color(0xFFFF856A), //6
  const Color(0xFF6784ED)
];

// Font Weights
List<FontWeight> fontWeights = [
  FontWeight.w300,
  FontWeight.w400,
  FontWeight.w500,
  FontWeight.w600,
  FontWeight.w700,
];

// Text Font Sizes
const double h1 = 24;
const double h2 = 22;
const double h3 = 18;
const double h4 = 16;
const double h5 = 14;
const double h6 = 12;

// Custom Text Widgets
Text h1Text(
    {required String text,
    required int weight,
    required int color,
    TextAlign? textAlign,
    int? maxLines}) {
  return Text(
    text,
    style: GoogleFonts.roboto(
      textStyle: TextStyle(
        fontSize: h1,
        fontWeight: fontWeights[weight],
        color: fontColors[color],
      ),
    ),
    textAlign: textAlign ?? TextAlign.left,
    overflow: TextOverflow.ellipsis,
    maxLines: maxLines,
  );
}

Text h2Text(
    {required String text,
    required int weight,
    required int color,
    TextAlign? textAlign,
    int? maxLines}) {
  return Text(
    text,
    style: GoogleFonts.roboto(
      textStyle: TextStyle(
        fontSize: h2,
        fontWeight: fontWeights[weight],
        color: fontColors[color],
      ),
    ),
    textAlign: textAlign ?? TextAlign.left,
    overflow: TextOverflow.ellipsis,
    maxLines: maxLines,
  );
}

Text h3Text(
    {required String text,
    required int weight,
    required int color,
    TextAlign? textAlign,
    int? maxLines}) {
  return Text(
    text,
    style: GoogleFonts.roboto(
      textStyle: TextStyle(
        fontSize: h3,
        fontWeight: fontWeights[weight],
        color: fontColors[color],
      ),
    ),
    textAlign: textAlign ?? TextAlign.left,
    overflow: TextOverflow.ellipsis,
    maxLines: maxLines,
  );
}

Text h4Text(
    {required String text,
    required int weight,
    required int color,
    TextAlign? textAlign,
    int? maxLines}) {
  return Text(
    text,
    style: GoogleFonts.roboto(
      textStyle: TextStyle(
        fontSize: h4,
        fontWeight: fontWeights[weight],
        color: fontColors[color],
      ),
    ),
    textAlign: textAlign ?? TextAlign.left,
    overflow: TextOverflow.ellipsis,
    maxLines: maxLines,
  );
}

Text h5Text(
    {required String text,
    required int weight,
    required int color,
    TextAlign? textAlign,
    int? maxLines}) {
  return Text(
    text,
    style: GoogleFonts.roboto(
      textStyle: TextStyle(
        fontSize: h5,
        fontWeight: fontWeights[weight],
        color: fontColors[color],
      ),
    ),
    textAlign: textAlign ?? TextAlign.left,
    overflow: TextOverflow.ellipsis,
    maxLines: maxLines,
  );
}

Text h6Text(
    {required String text,
    required int weight,
    required int color,
    TextAlign? textAlign,
    int? maxLines}) {
  return Text(
    text,
    style: GoogleFonts.roboto(
      textStyle: TextStyle(
        fontSize: h6,
        fontWeight: fontWeights[weight],
        color: fontColors[color],
      ),
    ),
    textAlign: textAlign ?? TextAlign.left,
    overflow: TextOverflow.ellipsis,
    maxLines: maxLines,
  );
}

TextStyle h5FormTextStyle() {
  return GoogleFonts.roboto(
    textStyle: TextStyle(
      fontSize: h5,
      fontWeight: fontWeights[1],
      color: fontColors[4],
    ),
  );
}

InputDecoration formInputDecoration(
    {String? label, bool? disabled = false, bool? hideCounter = false}) {
  return InputDecoration(
    hintText: label ?? '',
    hintStyle: GoogleFonts.roboto(
      textStyle: TextStyle(
        color: fontColors[3],
        fontSize: h5,
        fontWeight: fontWeights[1],
      ),
    ),
    counterText: hideCounter! ? '' : null,
    labelText: label != null ? label.toUpperCase() : '',
    labelStyle: GoogleFonts.oswald(
      textStyle: TextStyle(
        color: fontColors[3],
        fontSize: h5,
        fontWeight: fontWeights[1],
      ),
    ),
    fillColor: disabled! ? const Color(0xFFAFAFAF) : Colors.white,
    filled: true,
    floatingLabelBehavior: FloatingLabelBehavior.never,
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(5.0),
      borderSide: BorderSide(
        width: 1.0,
        color: borderColors[1],
      ),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(5.0),
      borderSide: BorderSide(
        width: 1.0,
        color: borderColors[4],
      ),
    ),
    errorBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(5.0),
      borderSide: BorderSide(
        width: 1.0,
        color: borderColors[0],
      ),
    ),
  );
}

normalButtonStyle() {
  return TextButton.styleFrom(
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
    backgroundColor: normalButtonColor,
    padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 20.0),
    fixedSize: const Size(130.0, 50.0),
  );
}

mobileNormalButtonStyle() {
  return TextButton.styleFrom(
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
    backgroundColor: normalButtonColor,
    padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
    fixedSize: const Size(100.0, 50.0),
  );
}

mobileDisabledNormalButtonStyle() {
  return TextButton.styleFrom(
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
    backgroundColor: disabledNormalButtonColor,
    padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
    fixedSize: const Size(100.0, 50.0),
  );
}

cancelButtonStyle() {
  return TextButton.styleFrom(
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
    backgroundColor: cancelButtonColor,
    padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 20.0),
    fixedSize: const Size(130.0, 50.0),
  );
}

mobileCancelButtonStyle() {
  return TextButton.styleFrom(
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
    backgroundColor: cancelButtonColor,
    padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
    fixedSize: const Size(100.0, 50.0),
  );
}

saveButtonStyle() {
  return TextButton.styleFrom(
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
    backgroundColor: saveButtonColor,
    padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 20.0),
    fixedSize: const Size(130.0, 50.0),
  );
}

mobileSaveButtonStyle() {
  return TextButton.styleFrom(
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
    backgroundColor: saveButtonColor,
    padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
    fixedSize: const Size(100.0, 50.0),
  );
}

mobileDisabledSaveButtonStyle() {
  return TextButton.styleFrom(
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
    backgroundColor: disabledSaveButtonColor,
    padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
    fixedSize: const Size(100.0, 50.0),
  );
}

customSaveButtonStyle(
    {required BuildContext context,
    bool? disabled = false,
    bool? isSquare = false}) {
  return TextButton.styleFrom(
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
    backgroundColor: disabled! ? disabledSaveButtonColor : saveButtonColor,
    padding: isSquare!
        ? const EdgeInsets.symmetric(vertical: 5.0, horizontal: 5.0)
        : Responsive.isMobile(context)
            ? const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0)
            : const EdgeInsets.symmetric(vertical: 10.0, horizontal: 20.0),
    fixedSize: isSquare
        ? const Size(50.0, 50.0)
        : Responsive.isMobile(context)
            ? const Size(100.0, 50.0)
            : const Size(130.0, 50.0),
  );
}

customCancelButtonStyle(
    {required BuildContext context,
    bool? disabled = false,
    bool? isSquare = false}) {
  return TextButton.styleFrom(
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
    backgroundColor: disabled! ? disabledCancelButtonColor : cancelButtonColor,
    padding: isSquare!
        ? const EdgeInsets.symmetric(vertical: 5.0, horizontal: 5.0)
        : Responsive.isMobile(context)
            ? const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0)
            : const EdgeInsets.symmetric(vertical: 10.0, horizontal: 20.0),
    fixedSize: isSquare
        ? const Size(50.0, 50.0)
        : Responsive.isMobile(context)
            ? const Size(100.0, 50.0)
            : const Size(130.0, 50.0),
  );
}

customNormalButtonStyle(
    {required BuildContext context,
    bool? disabled = false,
    bool? isSquare = false}) {
  return TextButton.styleFrom(
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
    backgroundColor: disabled! ? disabledNormalButtonColor : normalButtonColor,
    padding: isSquare!
        ? const EdgeInsets.symmetric(vertical: 5.0, horizontal: 5.0)
        : Responsive.isMobile(context)
            ? const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0)
            : const EdgeInsets.symmetric(vertical: 10.0, horizontal: 20.0),
    fixedSize: isSquare
        ? const Size(50.0, 50.0)
        : Responsive.isMobile(context)
            ? const Size(100.0, 50.0)
            : const Size(130.0, 50.0),
  );
}

disabledSaveButtonStyle() {
  return TextButton.styleFrom(
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
    backgroundColor: disabledSaveButtonColor,
    padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 20.0),
    fixedSize: const Size(130.0, 50.0),
  );
}

menuCardDecoration() {
  return BoxDecoration(
    color: Colors.white,
    borderRadius: BorderRadius.circular(10.0),
    boxShadow: const [
      BoxShadow(
        color: shadowColor,
        blurRadius: 20.0,
        offset: Offset(2.0, 10.0),
      )
    ],
  );
}

InputDecoration searchTextInputDecoration({String? label}) {
  return InputDecoration(
    hintText: label,
    hintStyle: TextStyle(
      color: fontColors[3],
      fontSize: h4,
      fontWeight: fontWeights[0],
    ),
    labelText: label,
    labelStyle: TextStyle(
      color: fontColors[3],
      fontSize: h4,
      fontWeight: fontWeights[0],
    ),
    fillColor: Colors.white,
    filled: true,
    floatingLabelBehavior: FloatingLabelBehavior.auto,
    enabledBorder: UnderlineInputBorder(
      borderRadius: BorderRadius.circular(5.0),
      borderSide: BorderSide(
        width: 2.0,
        color: borderColors[1],
      ),
    ),
    focusedBorder: UnderlineInputBorder(
      borderRadius: BorderRadius.circular(5.0),
      borderSide: BorderSide(
        width: 2.0,
        color: borderColors[4],
      ),
    ),
  );
}

InputDecoration searchFieldDecoration() {
  return InputDecoration(
    hintStyle: TextStyle(
      color: fontColors[3],
      fontSize: h4,
      fontWeight: fontWeights[0],
    ),
    fillColor: Colors.white,
    filled: true,
    prefixIcon: Icon(Icons.search, color: fontColors[3]),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(5.0),
      borderSide: const BorderSide(
        width: 1.0,
        color: Colors.white,
      ),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(5.0),
      borderSide: BorderSide(
        width: 1.0,
        color: borderColors[4],
      ),
    ),
  );
}

InputDecoration filterDecoration({String? label}) {
  return InputDecoration(
    labelText: label,
    labelStyle: TextStyle(
      color: fontColors[3],
      fontSize: h4,
      fontWeight: fontWeights[0],
    ),
    fillColor: Colors.white,
    filled: true,
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(5.0),
      borderSide: const BorderSide(
        width: 1.0,
        color: Colors.white,
      ),
    ),
  );
}

// Gradient Decorations
var loginGradDecor = BoxDecoration(
  gradient: const LinearGradient(
    colors: [loginGrad1, loginGrad2],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  ),
  borderRadius: BorderRadius.circular(10.0),
);

var buttonGradDecor = BoxDecoration(
  gradient: const LinearGradient(
    colors: [buttonGrad1, buttonGrad2],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  ),
  borderRadius: BorderRadius.circular(10.0),
);

// Card Decorations
var dashboardCardDecoration = BoxDecoration(
  color: dashboardCardColor,
  borderRadius: BorderRadius.circular(10.0),
  boxShadow: const [
    BoxShadow(
      color: shadowColor,
      blurRadius: 20.0,
      offset: Offset(2.0, 8.0),
    )
  ],
);

var dashboardCardIconDecoration = BoxDecoration(
  color: Colors.white,
  borderRadius: BorderRadius.circular(10.0),
  border: Border.all(
    color: dashboardIconBorderColor,
    width: 1.0,
  ),
);

var subAlertDialogDecoration = BoxDecoration(
  color: subAlertDialogColor,
  borderRadius: BorderRadius.circular(10.0),
);

loginButtonStyle() {
  return TextButton.styleFrom(
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
  );
}

mobileGOButtonStyle() {
  return TextButton.styleFrom(
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
    backgroundColor: normalButtonColor,
    fixedSize: const Size(50.0, 50.0),
  );
}

normalSquareButtonStyle() {
  return TextButton.styleFrom(
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
    backgroundColor: normalButtonColor,
    padding: const EdgeInsets.all(10.0),
    fixedSize: const Size(50.0, 50.0),
  );
}

normalThinButtonStyle() {
  return TextButton.styleFrom(
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
    backgroundColor: normalButtonColor,
    padding: const EdgeInsets.symmetric(vertical: 0.0, horizontal: 10.0),
    fixedSize: const Size(50.0, 50.0),
  );
}

navButtonStyle(bool selected) {
  return TextButton.styleFrom(
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
    backgroundColor: selected ? normalButtonColor : cancelButtonColor,
    padding: const EdgeInsets.symmetric(vertical: 0.0, horizontal: 10.0),
    fixedSize: const Size(70.0, 40.0),
  );
}

disabledSquareButtonStyle() {
  return TextButton.styleFrom(
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
    backgroundColor: disabledNormalButtonColor,
    padding: const EdgeInsets.all(10.0),
    fixedSize: const Size(50.0, 50.0),
  );
}

customSnackBar({required BuildContext context, required String message}) {
  return ScaffoldMessenger.of(context).showSnackBar(SnackBar(
    content: h4Text(text: message, weight: 1, color: 1, maxLines: 2),
    backgroundColor: primaryColor,
  ));
}

tableTag({required String label}) {
  return Container(
    height: 30.0,
    padding: const EdgeInsets.symmetric(vertical: 5.0, horizontal: 10.0),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(5.0),
      color: tableTagColor,
    ),
    child: Center(child: h5Text(text: label, weight: 1, color: 1)),
  );
}

userTableTag1({required String label, required bool state}) {
  return Container(
    height: 30.0,
    padding: const EdgeInsets.symmetric(vertical: 5.0, horizontal: 10.0),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(5.0),
      color: state ? activeUserColor : inactiveUserColor,
    ),
    child: Center(child: h5Text(text: label, weight: 1, color: 1)),
  );
}

userTableTag2({required String label, required bool state}) {
  return Container(
    height: 30.0,
    padding: const EdgeInsets.symmetric(vertical: 5.0, horizontal: 10.0),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(5.0),
      color: state ? tableTagColor : disabledColor,
    ),
    child: Center(child: h5Text(text: label, weight: 1, color: 1)),
  );
}

priorityTableTag({required String label}) {
  return Container(
    height: 30.0,
    padding: const EdgeInsets.symmetric(vertical: 5.0, horizontal: 10.0),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(5.0),
      color: label == 'High'
          ? highPriorityColor
          : label == 'Med'
              ? mediumPriorityColor
              : lowPriorityColor,
    ),
    child: Center(child: h5Text(text: label, weight: 1, color: 1)),
  );
}

priority2TableTag({required String label}) {
  return Container(
    height: 30.0,
    padding: const EdgeInsets.symmetric(vertical: 5.0, horizontal: 10.0),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(5.0),
      color: label == 'High'
          ? highPriorityColor
          : label == 'Medium'
              ? mediumPriorityColor
              : lowPriorityColor,
    ),
    child: Center(child: h5Text(text: label, weight: 1, color: 1)),
  );
}

subPageTag({required String label, required bool state}) {
  return Container(
    height: 30.0,
    padding:
        EdgeInsets.symmetric(vertical: 1.0, horizontal: state ? 10.0 : 0.0),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(5.0),
      color: state ? highlightColor : const Color(0x00FFFFFF),
    ),
    child: Center(child: h4Text(text: label, weight: 1, color: state ? 1 : 3)),
  );
}
